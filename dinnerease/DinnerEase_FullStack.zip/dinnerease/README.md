# 🍳 DinnerEase — AI Weekly Meal Planner

> Your tired brain deserves a break. No planning. No thinking. Just dinner.

---

## Project Structure

```
dinnerease/
├── backend/          ← Express.js REST API
│   ├── server.js     ← Main server file
│   └── package.json
└── frontend/         ← React + Vite app
    ├── src/
    │   ├── App.jsx   ← Full app (single file)
    │   └── main.jsx  ← Entry point
    ├── index.html
    ├── vite.config.js
    └── package.json
```

---

## Quick Start

### 1. Start the Backend

```bash
cd backend
npm install
npm start
# → Running on http://localhost:5000
```

### 2. Start the Frontend

```bash
cd frontend
npm install
npm run dev
# → Running on http://localhost:3000
```

Then open **http://localhost:3000** in your browser.

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/setup` | Generate 7-day meal plan |
| POST | `/api/today` | Get today's meal by ingredients |
| GET | `/api/meals` | List all meals |
| POST | `/api/xp` | Earn XP for sharing |

### POST /api/setup
```json
{
  "location": "India",
  "skillLevel": "beginner | intermediate | experienced",
  "diet": "veg | non-veg | both"
}
```

### POST /api/today
```json
{
  "ingredients": ["Eggs", "Rice", "Onions"],
  "diet": "non-veg",
  "skillLevel": "beginner"
}
```

### POST /api/xp
```json
{ "currentXP": 30 }
```

---

## Features Implemented

- ✅ Onboarding: skill level + diet + ingredient selection
- ✅ AI meal matching based on available ingredients
- ✅ 7-day meal plan generation
- ✅ Daily "What to cook?" screen with steps
- ✅ 2 alternative meal options
- ✅ Ingredient change / regenerate
- ✅ XP rewards system (share → earn XP → claim vouchers)
- ✅ Weekly plan calendar view
- ✅ Swiggy / Zomato voucher redemption
- ✅ Works offline (fallback mock data if backend is down)

---

## Deploy to Production

### Backend → Railway / Render
```bash
# Set environment variable:
PORT=5000
```

### Frontend → Vercel / Netlify
```bash
cd frontend
npm run build
# Deploy the /dist folder
```

Update the API constant in `App.jsx`:
```js
const API = "https://your-backend-url.railway.app/api";
```

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, CSS-in-JS |
| Backend | Node.js, Express.js |
| Fonts | Playfair Display, DM Sans (Google Fonts) |
| Deployment | Vercel (frontend) + Railway (backend) |
