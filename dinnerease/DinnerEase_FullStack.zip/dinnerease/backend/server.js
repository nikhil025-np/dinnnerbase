const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// ─── Meal Database ───────────────────────────────────────────────────────────
const MEALS = [
  {
    id: 1, name: "Masala Egg Rice", time: 15, type: "working_professional",
    diet: "non-veg", calories: 380,
    ingredients: ["Eggs", "Rice", "Onions", "Tomatoes", "Spices"],
    steps: ["Boil rice until fluffy.", "Scramble eggs with onions and tomatoes.", "Mix rice with egg masala.", "Season with salt and spices. Serve hot."]
  },
  {
    id: 2, name: "Dal Tadka & Rice", time: 20, type: "working_professional",
    diet: "veg", calories: 420,
    ingredients: ["Rice", "Onions", "Tomatoes", "Spices"],
    steps: ["Cook rice separately.", "Boil dal with turmeric.", "Prepare tadka with mustard seeds, onion, tomato.", "Pour tadka over dal. Serve with rice."]
  },
  {
    id: 3, name: "Bread Omelette", time: 10, type: "bachelor_boy",
    diet: "non-veg", calories: 310,
    ingredients: ["Eggs", "Bread", "Onions", "Spices"],
    steps: ["Beat eggs with chopped onions and spices.", "Cook omelette in butter on medium heat.", "Place between toasted bread slices.", "Serve immediately."]
  },
  {
    id: 4, name: "Aloo Paratha", time: 20, type: "bachelor_girl",
    diet: "veg", calories: 350,
    ingredients: ["Potatoes", "Onions", "Spices"],
    steps: ["Boil and mash potatoes with spices and onions.", "Stuff into rolled dough circles.", "Cook on tawa with butter until golden.", "Serve with curd or pickle."]
  },
  {
    id: 5, name: "Tomato Egg Curry", time: 18, type: "working_professional",
    diet: "non-veg", calories: 340,
    ingredients: ["Eggs", "Tomatoes", "Onions", "Spices"],
    steps: ["Hard boil eggs and set aside.", "Saute onions until golden, add tomatoes.", "Add spices and cook to a thick gravy.", "Add halved eggs and simmer 5 mins."]
  },
  {
    id: 6, name: "Paneer Bhurji", time: 15, type: "bachelor_girl",
    diet: "veg", calories: 390,
    ingredients: ["Onions", "Tomatoes", "Spices"],
    steps: ["Crumble paneer and set aside.", "Saute onions, green chilli, tomatoes.", "Add spices and crumbled paneer.", "Cook 5 mins, garnish with coriander."]
  },
  {
    id: 7, name: "Fried Rice", time: 15, type: "bachelor_boy",
    diet: "veg", calories: 360,
    ingredients: ["Rice", "Onions", "Spices"],
    steps: ["Cook and cool rice (day-old works best).", "Stir fry onions in high heat.", "Add rice and soy sauce.", "Toss well, season and serve hot."]
  },
  {
    id: 8, name: "Poha", time: 12, type: "working_professional",
    diet: "veg", calories: 280,
    ingredients: ["Onions", "Tomatoes", "Spices", "Potatoes"],
    steps: ["Rinse poha and drain well.", "Saute mustard seeds, curry leaves, onions.", "Add potatoes and cook 5 mins.", "Add poha, lemon juice, mix gently."]
  },
];

// ─── Routes ──────────────────────────────────────────────────────────────────

// POST /api/setup → generate 7-day meal plan
app.post('/api/setup', (req, res) => {
  const { location, skillLevel, diet } = req.body;

  // map skill level to user type
  const typeMap = {
    beginner: 'bachelor_boy',
    intermediate: 'bachelor_girl',
    experienced: 'working_professional'
  };
  const userType = typeMap[skillLevel] || 'working_professional';

  // filter meals
  let pool = MEALS.filter(m =>
    (diet === 'both' || m.diet === diet) &&
    (m.type === userType || m.type === 'working_professional')
  );

  if (pool.length < 7) pool = [...pool, ...MEALS].slice(0, 7);

  // generate 7-day plan
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const plan = days.map((day, i) => ({
    day,
    meal: pool[i % pool.length]
  }));

  res.json({ success: true, plan, userType });
});

// POST /api/today → get today's meal based on ingredients
app.post('/api/today', (req, res) => {
  const { ingredients, diet, skillLevel } = req.body;

  const typeMap = { beginner: 'bachelor_boy', intermediate: 'bachelor_girl', experienced: 'working_professional' };
  const userType = typeMap[skillLevel] || 'working_professional';

  // score meals by matching ingredients
  const scored = MEALS
    .filter(m => diet === 'both' || m.diet === diet)
    .map(meal => {
      const matches = meal.ingredients.filter(ing =>
        ingredients.some(ui => ui.toLowerCase().includes(ing.toLowerCase()) || ing.toLowerCase().includes(ui.toLowerCase()))
      );
      return { ...meal, score: matches.length };
    })
    .sort((a, b) => b.score - a.score);

  const primary = scored[0];
  const alternatives = scored.slice(1, 3);

  res.json({ success: true, primary, alternatives });
});

// GET /api/meals → all meals
app.get('/api/meals', (req, res) => res.json(MEALS));

// POST /api/xp → earn XP for sharing
app.post('/api/xp', (req, res) => {
  const { currentXP } = req.body;
  const newXP = (currentXP || 0) + 10;
  const vouchers = [];
  if (newXP >= 100) vouchers.push({ name: 'Swiggy Voucher', value: '₹50 off' });
  if (newXP >= 200) vouchers.push({ name: 'Zomato Voucher', value: '₹100 off' });
  res.json({ success: true, xp: newXP, vouchers });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`DinnerEase backend running on port ${PORT}`));
