import { useState, useEffect } from "react";

const API = "http://localhost:5000/api";

const INGREDIENTS_LIST = [
  "Eggs", "Rice", "Onions", "Tomatoes", "Potatoes",
  "Bread", "Spices", "Butter", "Paneer", "Dal"
];

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const todayIndex = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;

// ─── Styles ──────────────────────────────────────────────────────────────────
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500;600&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --cream: #FDF8F3;
    --warm: #F5EDE0;
    --orange: #E8631A;
    --orange-light: #F5894A;
    --brown: #3D1F0A;
    --brown-mid: #7A4419;
    --green: #2D6A4F;
    --green-light: #95D5B2;
    --gray: #8B7355;
    --white: #FFFFFF;
    --shadow: 0 4px 24px rgba(61,31,10,0.10);
    --shadow-lg: 0 12px 48px rgba(61,31,10,0.16);
  }

  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--cream);
    color: var(--brown);
    min-height: 100vh;
  }

  .app { max-width: 420px; margin: 0 auto; min-height: 100vh; position: relative; }

  /* Header */
  .header {
    background: var(--brown);
    padding: 20px 24px 16px;
    display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 100;
  }
  .logo { font-family: 'Playfair Display', serif; font-size: 24px; color: var(--cream); letter-spacing: -0.5px; }
  .logo span { color: var(--orange-light); }
  .xp-badge {
    background: var(--orange); color: white; border-radius: 20px;
    padding: 6px 14px; font-size: 13px; font-weight: 600;
    display: flex; align-items: center; gap: 6px; cursor: pointer;
    transition: transform 0.15s;
  }
  .xp-badge:hover { transform: scale(1.05); }

  /* Screens */
  .screen { padding: 24px; animation: fadeUp 0.4s ease; }
  @keyframes fadeUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }

  /* Hero */
  .hero {
    background: linear-gradient(145deg, var(--brown) 0%, var(--brown-mid) 100%);
    border-radius: 24px; padding: 36px 28px; margin-bottom: 28px;
    position: relative; overflow: hidden;
  }
  .hero::before {
    content: '🍳'; position: absolute; right: 20px; top: 20px;
    font-size: 64px; opacity: 0.15;
  }
  .hero-tag {
    background: var(--orange); color: white; border-radius: 20px;
    padding: 4px 12px; font-size: 11px; font-weight: 600;
    display: inline-block; margin-bottom: 14px; letter-spacing: 1px;
    text-transform: uppercase;
  }
  .hero h1 {
    font-family: 'Playfair Display', serif;
    font-size: 32px; color: var(--cream); line-height: 1.15; margin-bottom: 12px;
  }
  .hero p { color: rgba(253,248,243,0.7); font-size: 15px; line-height: 1.6; margin-bottom: 28px; }

  /* Buttons */
  .btn {
    width: 100%; padding: 16px; border-radius: 14px; border: none;
    font-family: 'DM Sans', sans-serif; font-size: 16px; font-weight: 600;
    cursor: pointer; transition: all 0.2s;
  }
  .btn-primary { background: var(--orange); color: white; }
  .btn-primary:hover { background: var(--orange-light); transform: translateY(-1px); box-shadow: var(--shadow); }
  .btn-secondary { background: var(--warm); color: var(--brown); margin-top: 10px; }
  .btn-secondary:hover { background: #EBE0D0; }
  .btn-outline {
    background: transparent; border: 2px solid var(--orange);
    color: var(--orange); padding: 12px; border-radius: 12px;
    font-weight: 600; cursor: pointer; transition: all 0.2s; font-size: 14px;
  }
  .btn-outline:hover { background: var(--orange); color: white; }
  .btn-small {
    padding: 8px 16px; border-radius: 10px; border: none;
    font-size: 13px; font-weight: 600; cursor: pointer;
    background: var(--orange); color: white; transition: all 0.15s;
  }
  .btn-small:hover { opacity: 0.85; }

  /* Feature pills */
  .features { display: flex; flex-direction: column; gap: 10px; margin-bottom: 24px; }
  .feature-item {
    display: flex; align-items: center; gap: 12px;
    background: white; border-radius: 14px; padding: 14px 16px;
    box-shadow: var(--shadow);
  }
  .feature-icon { font-size: 22px; width: 36px; text-align: center; }
  .feature-text { font-size: 14px; font-weight: 500; color: var(--brown); }
  .feature-sub { font-size: 12px; color: var(--gray); }

  /* Setup form */
  .setup-header {
    font-family: 'Playfair Display', serif;
    font-size: 26px; margin-bottom: 6px;
  }
  .setup-sub { color: var(--gray); font-size: 14px; margin-bottom: 28px; }

  .form-group { margin-bottom: 22px; }
  .form-label { font-size: 13px; font-weight: 600; color: var(--gray); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; display: block; }

  .option-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .option-btn {
    background: white; border: 2px solid #E8DDD0;
    border-radius: 12px; padding: 14px 12px; cursor: pointer;
    text-align: center; transition: all 0.2s; font-family: 'DM Sans', sans-serif;
  }
  .option-btn .opt-icon { font-size: 24px; display: block; margin-bottom: 4px; }
  .option-btn .opt-label { font-size: 13px; font-weight: 600; color: var(--brown); }
  .option-btn .opt-sub { font-size: 11px; color: var(--gray); }
  .option-btn.selected { border-color: var(--orange); background: #FFF3EB; }

  /* Ingredients */
  .ing-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .ing-btn {
    background: white; border: 2px solid #E8DDD0; border-radius: 12px;
    padding: 12px; cursor: pointer; text-align: center;
    transition: all 0.2s; font-family: 'DM Sans', sans-serif;
    display: flex; align-items: center; gap: 8px;
  }
  .ing-btn span:first-child { font-size: 20px; }
  .ing-btn span:last-child { font-size: 13px; font-weight: 500; color: var(--brown); }
  .ing-btn.selected { border-color: var(--green); background: #F0FAF5; }

  /* Meal Card */
  .meal-card {
    background: white; border-radius: 20px; overflow: hidden;
    box-shadow: var(--shadow-lg); margin-bottom: 20px;
  }
  .meal-image {
    height: 200px; background: linear-gradient(135deg, var(--warm) 0%, #E8D5BC 100%);
    display: flex; align-items: center; justify-content: center;
    font-size: 72px; position: relative;
  }
  .meal-badge {
    position: absolute; top: 12px; left: 12px;
    background: var(--brown); color: var(--cream);
    border-radius: 8px; padding: 4px 10px; font-size: 12px; font-weight: 600;
  }
  .meal-share-btn {
    position: absolute; top: 12px; right: 12px;
    background: white; border: none; border-radius: 50%;
    width: 36px; height: 36px; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px; box-shadow: var(--shadow);
    transition: transform 0.15s;
  }
  .meal-share-btn:hover { transform: scale(1.1); }
  .meal-body { padding: 20px; }
  .meal-name { font-family: 'Playfair Display', serif; font-size: 24px; margin-bottom: 4px; }
  .meal-meta { display: flex; gap: 12px; margin-bottom: 16px; }
  .meal-tag {
    display: flex; align-items: center; gap: 4px;
    font-size: 12px; color: var(--gray); font-weight: 500;
  }
  .ing-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 16px; }
  .ing-tag {
    background: var(--warm); color: var(--brown-mid);
    border-radius: 20px; padding: 4px 12px; font-size: 12px; font-weight: 500;
  }
  .steps-list { list-style: none; }
  .step-item {
    display: flex; gap: 12px; padding: 10px 0;
    border-bottom: 1px solid var(--warm);
  }
  .step-item:last-child { border-bottom: none; }
  .step-num {
    background: var(--orange); color: white; border-radius: 50%;
    width: 24px; height: 24px; display: flex; align-items: center;
    justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; margin-top: 1px;
  }
  .step-text { font-size: 14px; line-height: 1.6; color: var(--brown); }

  /* Weekly Plan */
  .week-grid { display: flex; flex-direction: column; gap: 10px; }
  .day-card {
    background: white; border-radius: 14px; padding: 14px 16px;
    display: flex; align-items: center; gap: 14px;
    box-shadow: var(--shadow); cursor: pointer; transition: all 0.2s;
    border: 2px solid transparent;
  }
  .day-card:hover { border-color: var(--orange); }
  .day-card.today { border-color: var(--orange); background: #FFF8F3; }
  .day-pill {
    background: var(--warm); border-radius: 10px; padding: 6px 10px;
    font-size: 12px; font-weight: 700; color: var(--brown-mid);
    text-transform: uppercase; letter-spacing: 0.5px; min-width: 44px; text-align: center;
  }
  .day-card.today .day-pill { background: var(--orange); color: white; }
  .day-meal-name { font-size: 15px; font-weight: 600; }
  .day-meal-time { font-size: 12px; color: var(--gray); }
  .today-badge {
    margin-left: auto; background: var(--orange); color: white;
    border-radius: 6px; padding: 2px 8px; font-size: 11px; font-weight: 700;
  }

  /* Alternatives */
  .alt-section { margin-top: 20px; }
  .alt-title { font-size: 14px; font-weight: 600; color: var(--gray); margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
  .alt-cards { display: flex; gap: 10px; }
  .alt-card {
    flex: 1; background: white; border-radius: 14px; padding: 14px;
    box-shadow: var(--shadow); cursor: pointer; border: 2px solid transparent;
    transition: all 0.2s;
  }
  .alt-card:hover { border-color: var(--orange); }
  .alt-emoji { font-size: 28px; margin-bottom: 8px; }
  .alt-name { font-size: 13px; font-weight: 600; }
  .alt-time { font-size: 12px; color: var(--gray); }

  /* Rewards */
  .xp-card {
    background: var(--brown); border-radius: 20px; padding: 24px;
    color: var(--cream); margin-bottom: 20px;
  }
  .xp-total { font-family: 'Playfair Display', serif; font-size: 48px; }
  .xp-label { font-size: 13px; opacity: 0.6; margin-bottom: 16px; }
  .xp-progress { background: rgba(255,255,255,0.15); border-radius: 10px; height: 8px; margin-bottom: 8px; }
  .xp-bar { background: var(--orange-light); border-radius: 10px; height: 100%; transition: width 0.5s ease; }
  .xp-next { font-size: 12px; opacity: 0.6; }
  .voucher-card {
    background: white; border-radius: 16px; padding: 18px;
    display: flex; align-items: center; gap: 14px;
    box-shadow: var(--shadow); margin-bottom: 10px;
  }
  .voucher-icon { font-size: 28px; }
  .voucher-name { font-size: 15px; font-weight: 600; }
  .voucher-value { font-size: 13px; color: var(--green); font-weight: 600; }
  .voucher-xp { margin-left: auto; font-size: 13px; color: var(--gray); }

  /* Nav */
  .nav {
    position: fixed; bottom: 0; left: 50%; transform: translateX(-50%);
    width: 100%; max-width: 420px;
    background: white; border-top: 1px solid #F0E8DC;
    display: flex; padding: 8px 0 16px;
    z-index: 100;
  }
  .nav-item {
    flex: 1; display: flex; flex-direction: column; align-items: center;
    gap: 3px; cursor: pointer; padding: 8px;
    transition: all 0.15s; border: none; background: none;
  }
  .nav-icon { font-size: 20px; }
  .nav-label { font-size: 10px; font-weight: 600; color: var(--gray); }
  .nav-item.active .nav-label { color: var(--orange); }
  .nav-dot { width: 4px; height: 4px; border-radius: 50%; background: var(--orange); }

  /* Toast */
  .toast {
    position: fixed; bottom: 90px; left: 50%; transform: translateX(-50%);
    background: var(--brown); color: var(--cream);
    padding: 12px 24px; border-radius: 30px; font-size: 14px; font-weight: 500;
    box-shadow: var(--shadow-lg); z-index: 999;
    animation: toastIn 0.3s ease;
  }
  @keyframes toastIn { from { opacity:0; transform: translateX(-50%) translateY(10px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }

  .spacer { height: 80px; }
  .section-title { font-family: 'Playfair Display', serif; font-size: 22px; margin-bottom: 6px; }
  .section-sub { color: var(--gray); font-size: 14px; margin-bottom: 20px; }

  .change-btn {
    display: flex; align-items: center; gap: 6px;
    background: var(--warm); border: none; border-radius: 10px;
    padding: 8px 14px; font-size: 13px; font-weight: 500;
    color: var(--brown-mid); cursor: pointer; margin-bottom: 16px;
    transition: all 0.15s;
  }
  .change-btn:hover { background: #EBE0D0; }

  .loading {
    display: flex; align-items: center; justify-content: center;
    padding: 40px; flex-direction: column; gap: 12px;
  }
  .spinner {
    width: 36px; height: 36px; border: 3px solid var(--warm);
    border-top-color: var(--orange); border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  .loading-text { color: var(--gray); font-size: 14px; }
`;

// ─── Meal Emojis ─────────────────────────────────────────────────────────────
const mealEmoji = (name = "") => {
  if (name.toLowerCase().includes("egg")) return "🍳";
  if (name.toLowerCase().includes("rice")) return "🍚";
  if (name.toLowerCase().includes("paneer")) return "🧀";
  if (name.toLowerCase().includes("dal")) return "🥘";
  if (name.toLowerCase().includes("bread") || name.toLowerCase().includes("paratha")) return "🫓";
  if (name.toLowerCase().includes("poha")) return "🥣";
  return "🍽️";
};

const ingEmoji = (ing) => {
  const map = { Eggs:"🥚", Rice:"🍚", Onions:"🧅", Tomatoes:"🍅", Potatoes:"🥔", Bread:"🍞", Spices:"🌶️", Butter:"🧈", Paneer:"🧀", Dal:"🫘" };
  return map[ing] || "🥗";
};

// ─── Components ──────────────────────────────────────────────────────────────

function MealCard({ meal, onShare, showSteps = true }) {
  if (!meal) return null;
  return (
    <div className="meal-card">
      <div className="meal-image">
        <span style={{fontSize:80}}>{mealEmoji(meal.name)}</span>
        <span className="meal-badge">{meal.diet === 'veg' ? '🌿 Veg' : '🍖 Non-Veg'}</span>
        {onShare && (
          <button className="meal-share-btn" onClick={onShare} title="Share & earn XP">
            🔗
          </button>
        )}
      </div>
      <div className="meal-body">
        <div className="meal-name">{meal.name}</div>
        <div className="meal-meta">
          <span className="meal-tag">⏱️ {meal.time} mins</span>
          <span className="meal-tag">🔥 {meal.calories} cal</span>
        </div>
        <div style={{fontWeight:600, fontSize:12, color:'var(--gray)', textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8}}>Ingredients</div>
        <div className="ing-tags">
          {meal.ingredients.map(ing => <span key={ing} className="ing-tag">{ing}</span>)}
        </div>
        {showSteps && <>
          <div style={{fontWeight:600, fontSize:12, color:'var(--gray)', textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:8}}>Steps</div>
          <ul className="steps-list">
            {meal.steps.map((step, i) => (
              <li key={i} className="step-item">
                <span className="step-num">{i + 1}</span>
                <span className="step-text">{step}</span>
              </li>
            ))}
          </ul>
        </>}
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("landing"); // landing | setup | home | week | rewards
  const [tab, setTab] = useState("today");
  const [setupStep, setSetupStep] = useState(0); // 0=skill, 1=diet, 2=ingredients

  const [skillLevel, setSkillLevel] = useState(null);
  const [diet, setDiet] = useState(null);
  const [selectedIngs, setSelectedIngs] = useState([]);

  const [plan, setPlan] = useState(null);
  const [todayMeal, setTodayMeal] = useState(null);
  const [alternatives, setAlternatives] = useState([]);
  const [loading, setLoading] = useState(false);

  const [xp, setXp] = useState(0);
  const [toast, setToast] = useState(null);
  const [viewMeal, setViewMeal] = useState(null);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  const toggleIng = (ing) => {
    setSelectedIngs(prev => prev.includes(ing) ? prev.filter(i => i !== ing) : [...prev, ing]);
  };

  const handleSetupComplete = async () => {
    setLoading(true);
    try {
      // generate weekly plan
      const r1 = await fetch(`${API}/setup`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skillLevel, diet, location: "India" })
      });
      const d1 = await r1.json();
      setPlan(d1.plan);

      // get today's meal
      const r2 = await fetch(`${API}/today`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ingredients: selectedIngs, diet, skillLevel })
      });
      const d2 = await r2.json();
      setTodayMeal(d2.primary);
      setAlternatives(d2.alternatives || []);
      setScreen("home");
    } catch (e) {
      // fallback mock data if backend not running
      const mock = { id:1, name:"Masala Egg Rice", time:15, diet:"non-veg", calories:380, ingredients:["Eggs","Rice","Onions","Tomatoes","Spices"], steps:["Boil rice until fluffy.","Scramble eggs with onions and tomatoes.","Mix rice with egg masala.","Season and serve hot."] };
      setTodayMeal(mock);
      setPlan(["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"].map((day,i)=>({day,meal:mock})));
      setAlternatives([
        { id:2, name:"Dal Tadka & Rice", time:20, diet:"veg", calories:420, ingredients:["Rice","Dal"], steps:["Cook rice.","Make dal tadka.","Serve."] },
        { id:3, name:"Bread Omelette", time:10, diet:"non-veg", calories:310, ingredients:["Eggs","Bread"], steps:["Beat eggs.","Cook omelette.","Serve between bread."] }
      ]);
      setScreen("home");
    }
    setLoading(false);
  };

  const handleShare = async () => {
    try {
      const r = await fetch(`${API}/xp`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentXP: xp })
      });
      const d = await r.json();
      setXp(d.xp);
    } catch {
      setXp(prev => prev + 10);
    }
    showToast("🎉 +10 XP earned! Keep sharing!");
  };

  const nextSetupStep = () => {
    if (setupStep === 0 && !skillLevel) { showToast("Please pick your skill level"); return; }
    if (setupStep === 1 && !diet) { showToast("Please pick a diet preference"); return; }
    if (setupStep === 2) { handleSetupComplete(); return; }
    setSetupStep(s => s + 1);
  };

  // ── Render Landing ────────────────────────────────────────────────────────
  if (screen === "landing") return (
    <div className="app">
      <style>{styles}</style>
      <div className="header">
        <div className="logo">Dinner<span>Ease</span></div>
      </div>
      <div className="screen">
        <div className="hero">
          <div className="hero-tag">AI Powered</div>
          <h1>Your tired brain deserves a break.</h1>
          <p>No planning. No thinking. Just simple dinner suggestions based on what you already have at home.</p>
          <button className="btn btn-primary" onClick={() => setScreen("setup")}>Let's Get Started →</button>
        </div>
        <div className="features">
          {[
            { icon: "⏱️", text: "30-second Sunday setup", sub: "Set once, eat all week" },
            { icon: "🧠", text: "Zero daily decisions", sub: "Open app, see meal, cook" },
            { icon: "📍", text: "Local ingredients only", sub: "No exotic items, no special trips" },
            { icon: "🎁", text: "Earn XP & vouchers", sub: "Share meals, get Swiggy rewards" },
          ].map((f, i) => (
            <div key={i} className="feature-item">
              <div className="feature-icon">{f.icon}</div>
              <div>
                <div className="feature-text">{f.text}</div>
                <div className="feature-sub">{f.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // ── Render Setup ─────────────────────────────────────────────────────────
  if (screen === "setup") return (
    <div className="app">
      <style>{styles}</style>
      <div className="header">
        <div className="logo">Dinner<span>Ease</span></div>
        <div style={{color:'rgba(253,248,243,0.5)', fontSize:13}}>Step {setupStep + 1} of 3</div>
      </div>
      <div className="screen">
        {/* Progress */}
        <div style={{background:'var(--warm)', borderRadius:10, height:6, marginBottom:28}}>
          <div style={{background:'var(--orange)', borderRadius:10, height:'100%', width:`${((setupStep+1)/3)*100}%`, transition:'width 0.3s'}} />
        </div>

        {setupStep === 0 && <>
          <div className="setup-header">What's your cooking level?</div>
          <div className="setup-sub">We'll match meals to your skill — no pressure.</div>
          <div className="form-group">
            <div className="option-grid">
              {[
                { val:"beginner", icon:"🥚", label:"Beginner", sub:"2–3 simple dishes" },
                { val:"intermediate", icon:"🍳", label:"Intermediate", sub:"Can follow recipes" },
                { val:"experienced", icon:"👨‍🍳", label:"Experienced", sub:"Comfortable cooking" },
                { val:"working_professional", icon:"⏰", label:"Time-Pressed", sub:"15–20 min max" },
              ].map(o => (
                <div key={o.val} className={`option-btn${skillLevel===o.val?' selected':''}`} onClick={() => setSkillLevel(o.val)}>
                  <span className="opt-icon">{o.icon}</span>
                  <span className="opt-label">{o.label}</span>
                  <span className="opt-sub">{o.sub}</span>
                </div>
              ))}
            </div>
          </div>
        </>}

        {setupStep === 1 && <>
          <div className="setup-header">Diet preference?</div>
          <div className="setup-sub">We'll only show meals that match what you eat.</div>
          <div className="form-group">
            <div className="option-grid">
              {[
                { val:"veg", icon:"🌿", label:"Vegetarian", sub:"Plant-based meals" },
                { val:"non-veg", icon:"🍖", label:"Non-Veg", sub:"Includes eggs & meat" },
                { val:"both", icon:"🥗", label:"Both", sub:"Show me everything" },
              ].map(o => (
                <div key={o.val} className={`option-btn${diet===o.val?' selected':''}`} onClick={() => setDiet(o.val)}>
                  <span className="opt-icon">{o.icon}</span>
                  <span className="opt-label">{o.label}</span>
                  <span className="opt-sub">{o.sub}</span>
                </div>
              ))}
            </div>
          </div>
        </>}

        {setupStep === 2 && <>
          <div className="setup-header">What's in your kitchen?</div>
          <div className="setup-sub">Tap everything you have right now. Takes 30 seconds.</div>
          <div className="form-group">
            <div className="ing-grid">
              {INGREDIENTS_LIST.map(ing => (
                <div key={ing} className={`ing-btn${selectedIngs.includes(ing)?' selected':''}`} onClick={() => toggleIng(ing)}>
                  <span>{ingEmoji(ing)}</span>
                  <span>{ing}</span>
                </div>
              ))}
            </div>
          </div>
          {selectedIngs.length > 0 && (
            <div style={{fontSize:13, color:'var(--green)', fontWeight:600, marginBottom:16}}>
              ✓ {selectedIngs.length} items selected
            </div>
          )}
        </>}

        {loading
          ? <div className="loading"><div className="spinner"/><div className="loading-text">Building your meal plan...</div></div>
          : <button className="btn btn-primary" onClick={nextSetupStep}>
              {setupStep === 2 ? "Generate My Meal Plan 🍽️" : "Continue →"}
            </button>
        }
        {setupStep > 0 && !loading && (
          <button className="btn btn-secondary" onClick={() => setSetupStep(s => s - 1)}>← Back</button>
        )}
      </div>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );

  // ── Render Main App ──────────────────────────────────────────────────────
  return (
    <div className="app">
      <style>{styles}</style>
      <div className="header">
        <div className="logo">Dinner<span>Ease</span></div>
        <div className="xp-badge" onClick={() => setTab("rewards")}>
          ⭐ {xp} XP
        </div>
      </div>

      {/* View single meal detail */}
      {viewMeal && (
        <div className="screen">
          <button className="change-btn" onClick={() => setViewMeal(null)}>← Back</button>
          <MealCard meal={viewMeal} onShare={handleShare} showSteps={true} />
          <div className="spacer"/>
        </div>
      )}

      {!viewMeal && tab === "today" && (
        <div className="screen">
          <div style={{fontSize:12, color:'var(--gray)', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:4}}>Today's Dinner</div>
          <div className="section-title">What to cook?</div>
          <button className="change-btn" onClick={() => setScreen("setup")}>
            🛒 Change Ingredients
          </button>
          <MealCard meal={todayMeal} onShare={handleShare} showSteps={true} />

          {alternatives.length > 0 && (
            <div className="alt-section">
              <div className="alt-title">Don't feel like it? Try these</div>
              <div className="alt-cards">
                {alternatives.map(m => (
                  <div key={m.id} className="alt-card" onClick={() => setViewMeal(m)}>
                    <div className="alt-emoji">{mealEmoji(m.name)}</div>
                    <div className="alt-name">{m.name}</div>
                    <div className="alt-time">⏱️ {m.time} mins</div>
                  </div>
                ))}
              </div>
            </div>
          )}
          <div className="spacer"/>
        </div>
      )}

      {!viewMeal && tab === "week" && (
        <div className="screen">
          <div className="section-title">This Week's Plan</div>
          <div className="section-sub">Set on Sunday, cooked all week.</div>
          <div className="week-grid">
            {(plan || []).map((item, i) => (
              <div key={item.day} className={`day-card${i === todayIndex ? " today" : ""}`} onClick={() => setViewMeal(item.meal)}>
                <div className="day-pill">{item.day.slice(0,3)}</div>
                <div>
                  <div className="day-meal-name">{item.meal?.name}</div>
                  <div className="day-meal-time">⏱️ {item.meal?.time} mins</div>
                </div>
                {i === todayIndex && <span className="today-badge">Today</span>}
              </div>
            ))}
          </div>
          <div className="spacer"/>
        </div>
      )}

      {!viewMeal && tab === "rewards" && (
        <div className="screen">
          <div className="xp-card">
            <div className="xp-total">{xp} XP</div>
            <div className="xp-label">Total earned</div>
            <div style={{display:'flex', gap:24, marginBottom:16}}>
              <div><div style={{fontSize:20, fontWeight:700}}>{Math.floor(xp/10)}</div><div style={{fontSize:11, opacity:0.6}}>Meals shared</div></div>
              <div><div style={{fontSize:20, fontWeight:700}}>{Math.floor(xp/100)}</div><div style={{fontSize:11, opacity:0.6}}>Vouchers claimed</div></div>
            </div>
            <div className="xp-progress"><div className="xp-bar" style={{width:`${Math.min((xp % 100), 100)}%`}}/></div>
            <div className="xp-next">{100 - (xp % 100)} XP to next voucher</div>
          </div>

          <div style={{fontWeight:600, fontSize:13, color:'var(--gray)', textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:12}}>How it works</div>
          <div style={{background:'var(--warm)', borderRadius:14, padding:16, marginBottom:20, fontSize:14, color:'var(--brown)'}}>
            <div style={{marginBottom:8}}>🔗 Share a meal suggestion = <strong>+10 XP</strong></div>
            <div>🎁 Collect 100 XP to claim a voucher</div>
          </div>

          <div style={{fontWeight:600, fontSize:13, color:'var(--gray)', textTransform:'uppercase', letterSpacing:'0.5px', marginBottom:12}}>Available Vouchers</div>
          {[
            { icon:"🟠", name:"Swiggy Voucher", value:"₹50 off", cost:100 },
            { icon:"🔴", name:"Zomato Voucher", value:"₹100 off", cost:200 },
          ].map(v => (
            <div key={v.name} className="voucher-card">
              <div className="voucher-icon">{v.icon}</div>
              <div>
                <div className="voucher-name">{v.name}</div>
                <div className="voucher-value">{v.value}</div>
              </div>
              <div className="voucher-xp">{v.cost} XP</div>
              {xp >= v.cost
                ? <button className="btn-small" onClick={() => showToast("🎉 Voucher claimed!")}>Claim</button>
                : <button className="btn-outline" style={{padding:'6px 12px', fontSize:12}} disabled>Need {v.cost - xp} more</button>
              }
            </div>
          ))}
          <div className="spacer"/>
        </div>
      )}

      {/* Bottom Nav */}
      <nav className="nav">
        {[
          { key:"today", icon:"🍽️", label:"Today" },
          { key:"week", icon:"📅", label:"This Week" },
          { key:"rewards", icon:"⭐", label:"Rewards" },
        ].map(n => (
          <button key={n.key} className={`nav-item${tab===n.key?' active':''}`} onClick={() => { setTab(n.key); setViewMeal(null); }}>
            <span className="nav-icon">{n.icon}</span>
            <span className="nav-label">{n.label}</span>
            {tab === n.key && <div className="nav-dot"/>}
          </button>
        ))}
      </nav>

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
